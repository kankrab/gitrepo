INSERT INTO ORDERS
(id,
user_id,
detail)
VALUES
(1,
1,
'order 1');

INSERT INTO ORDERS
(id,
user_id,
detail)
VALUES
(2,
1,
'order 2');

INSERT INTO ORDERS
(id,
user_id,
detail)
VALUES
(3,
1,
'order 3');