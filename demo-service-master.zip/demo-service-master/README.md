# Demo of spring boot with mysql database

Step 1 :: Start user service (9001)
```
$cd user-service
$mvn clean install  && java -jar ./target/user-service.jar
```

Step 2 :: Start order service (9002)
```
$cd ordert-service
$mvn clean install  && java -jar ./target/order-service.jar
```
