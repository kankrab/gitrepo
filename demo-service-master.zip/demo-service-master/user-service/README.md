# How to run the user service ?

```
$mvn clean package
$java -jar ./target/user-service.jar
```

And go to URL http://localhost:9001/user
