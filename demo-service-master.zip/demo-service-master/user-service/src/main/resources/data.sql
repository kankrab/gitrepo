INSERT INTO USERS
(id,
firstname,
lastname)
VALUES
(1,
'somkiat',
'pui');